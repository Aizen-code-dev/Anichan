package com.anime.Aniflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AniflixApplication {

	public static void main(String[] args) {
		// Start the Spring Boot application
		SpringApplication.run(AniflixApplication.class, args);


	}
}
