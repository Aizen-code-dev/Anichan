package com.anime.Aniflix.Model.zorowatch;

public class ZoroSubtitle {
    private String url;
    private String lang;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }
// Getters and Setters
}
